compute-sanitizer --tool memcheck --leak-check full ./build_debug/program
