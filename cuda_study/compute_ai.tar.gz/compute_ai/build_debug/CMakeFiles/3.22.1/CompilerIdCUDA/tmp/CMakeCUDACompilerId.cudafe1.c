# 1 "CMakeCUDACompilerId.cu"
# 64 "CMakeCUDACompilerId.cu"
extern const char *info_compiler;

extern const char *info_simulate;
# 336 "CMakeCUDACompilerId.cu"
static const char info_version[50];
# 365 "CMakeCUDACompilerId.cu"
static const char info_simulate_version[41];
# 385 "CMakeCUDACompilerId.cu"
extern const char *info_platform;
extern const char *info_arch;



extern const char *info_language_standard_default;
# 406 "CMakeCUDACompilerId.cu"
extern const char *info_language_extensions_default;
# 534 "/usr/include/c++/11/bits/cpp_type_traits.h" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt24__is_memcmp_ordered_withISt4byteS0_Lb1EE7__valueE */ const char _ZNSt24__is_memcmp_ordered_withISt4byteS0_Lb1EE7__valueE __attribute__((visibility("default")));
# 206 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base14is_specializedE */ const char _ZNSt21__numeric_limits_base14is_specializedE __attribute__((visibility("default")));




extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base6digitsE */ const int _ZNSt21__numeric_limits_base6digitsE __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base8digits10E */ const int _ZNSt21__numeric_limits_base8digits10E __attribute__((visibility("default")));




extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base12max_digits10E */ const int _ZNSt21__numeric_limits_base12max_digits10E __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base9is_signedE */ const char _ZNSt21__numeric_limits_base9is_signedE __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base10is_integerE */ const char _ZNSt21__numeric_limits_base10is_integerE __attribute__((visibility("default")));




extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base8is_exactE */ const char _ZNSt21__numeric_limits_base8is_exactE __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base5radixE */ const int _ZNSt21__numeric_limits_base5radixE __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base12min_exponentE */ const int _ZNSt21__numeric_limits_base12min_exponentE __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base14min_exponent10E */ const int _ZNSt21__numeric_limits_base14min_exponent10E __attribute__((visibility("default")));




extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base12max_exponentE */ const int _ZNSt21__numeric_limits_base12max_exponentE __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base14max_exponent10E */ const int _ZNSt21__numeric_limits_base14max_exponent10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base12has_infinityE */ const char _ZNSt21__numeric_limits_base12has_infinityE __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base13has_quiet_NaNE */ const char _ZNSt21__numeric_limits_base13has_quiet_NaNE __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base17has_signaling_NaNE */ const char _ZNSt21__numeric_limits_base17has_signaling_NaNE __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt21__numeric_limits_base10has_denormE __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base15has_denorm_lossE */ const char _ZNSt21__numeric_limits_base15has_denorm_lossE __attribute__((visibility("default")));



extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base9is_iec559E */ const char _ZNSt21__numeric_limits_base9is_iec559E __attribute__((visibility("default")));




extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base10is_boundedE */ const char _ZNSt21__numeric_limits_base10is_boundedE __attribute__((visibility("default")));
# 288 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base9is_moduloE */ const char _ZNSt21__numeric_limits_base9is_moduloE __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base5trapsE */ const char _ZNSt21__numeric_limits_base5trapsE __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base15tinyness_beforeE */ const char _ZNSt21__numeric_limits_base15tinyness_beforeE __attribute__((visibility("default")));




extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base11round_styleE */ const enum _ZSt17float_round_style _ZNSt21__numeric_limits_base11round_styleE __attribute__((visibility("default")));
# 386 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE14is_specializedE */ const char _ZNSt14numeric_limitsIbE14is_specializedE __attribute__((visibility("default")));
# 398 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE6digitsE */ const int _ZNSt14numeric_limitsIbE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE8digits10E */ const int _ZNSt14numeric_limitsIbE8digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE12max_digits10E */ const int _ZNSt14numeric_limitsIbE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE9is_signedE */ const char _ZNSt14numeric_limitsIbE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE10is_integerE */ const char _ZNSt14numeric_limitsIbE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE8is_exactE */ const char _ZNSt14numeric_limitsIbE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE5radixE */ const int _ZNSt14numeric_limitsIbE5radixE __attribute__((visibility("default")));
# 414 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE12min_exponentE */ const int _ZNSt14numeric_limitsIbE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE14min_exponent10E */ const int _ZNSt14numeric_limitsIbE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE12max_exponentE */ const int _ZNSt14numeric_limitsIbE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE14max_exponent10E */ const int _ZNSt14numeric_limitsIbE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE12has_infinityE */ const char _ZNSt14numeric_limitsIbE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIbE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIbE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIbE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIbE15has_denorm_lossE __attribute__((visibility("default")));
# 438 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE9is_iec559E */ const char _ZNSt14numeric_limitsIbE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE10is_boundedE */ const char _ZNSt14numeric_limitsIbE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE9is_moduloE */ const char _ZNSt14numeric_limitsIbE9is_moduloE __attribute__((visibility("default")));




extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE5trapsE */ const char _ZNSt14numeric_limitsIbE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIbE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIbE11round_styleE __attribute__((visibility("default")));
# 455 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE14is_specializedE */ const char _ZNSt14numeric_limitsIcE14is_specializedE __attribute__((visibility("default")));
# 468 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE6digitsE */ const int _ZNSt14numeric_limitsIcE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE8digits10E */ const int _ZNSt14numeric_limitsIcE8digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE12max_digits10E */ const int _ZNSt14numeric_limitsIcE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE9is_signedE */ const char _ZNSt14numeric_limitsIcE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE10is_integerE */ const char _ZNSt14numeric_limitsIcE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE8is_exactE */ const char _ZNSt14numeric_limitsIcE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE5radixE */ const int _ZNSt14numeric_limitsIcE5radixE __attribute__((visibility("default")));
# 484 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE12min_exponentE */ const int _ZNSt14numeric_limitsIcE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE14min_exponent10E */ const int _ZNSt14numeric_limitsIcE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE12max_exponentE */ const int _ZNSt14numeric_limitsIcE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE14max_exponent10E */ const int _ZNSt14numeric_limitsIcE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE12has_infinityE */ const char _ZNSt14numeric_limitsIcE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIcE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIcE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIcE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIcE15has_denorm_lossE __attribute__((visibility("default")));
# 508 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE9is_iec559E */ const char _ZNSt14numeric_limitsIcE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE10is_boundedE */ const char _ZNSt14numeric_limitsIcE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE9is_moduloE */ const char _ZNSt14numeric_limitsIcE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE5trapsE */ const char _ZNSt14numeric_limitsIcE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIcE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIcE11round_styleE __attribute__((visibility("default")));
# 522 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE14is_specializedE */ const char _ZNSt14numeric_limitsIaE14is_specializedE __attribute__((visibility("default")));
# 535 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE6digitsE */ const int _ZNSt14numeric_limitsIaE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE8digits10E */ const int _ZNSt14numeric_limitsIaE8digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE12max_digits10E */ const int _ZNSt14numeric_limitsIaE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE9is_signedE */ const char _ZNSt14numeric_limitsIaE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE10is_integerE */ const char _ZNSt14numeric_limitsIaE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE8is_exactE */ const char _ZNSt14numeric_limitsIaE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE5radixE */ const int _ZNSt14numeric_limitsIaE5radixE __attribute__((visibility("default")));
# 552 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE12min_exponentE */ const int _ZNSt14numeric_limitsIaE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE14min_exponent10E */ const int _ZNSt14numeric_limitsIaE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE12max_exponentE */ const int _ZNSt14numeric_limitsIaE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE14max_exponent10E */ const int _ZNSt14numeric_limitsIaE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE12has_infinityE */ const char _ZNSt14numeric_limitsIaE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIaE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIaE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIaE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIaE15has_denorm_lossE __attribute__((visibility("default")));
# 578 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE9is_iec559E */ const char _ZNSt14numeric_limitsIaE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE10is_boundedE */ const char _ZNSt14numeric_limitsIaE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE9is_moduloE */ const char _ZNSt14numeric_limitsIaE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE5trapsE */ const char _ZNSt14numeric_limitsIaE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIaE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIaE11round_styleE __attribute__((visibility("default")));
# 592 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE14is_specializedE */ const char _ZNSt14numeric_limitsIhE14is_specializedE __attribute__((visibility("default")));
# 605 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE6digitsE */ const int _ZNSt14numeric_limitsIhE6digitsE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE8digits10E */ const int _ZNSt14numeric_limitsIhE8digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE12max_digits10E */ const int _ZNSt14numeric_limitsIhE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE9is_signedE */ const char _ZNSt14numeric_limitsIhE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE10is_integerE */ const char _ZNSt14numeric_limitsIhE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE8is_exactE */ const char _ZNSt14numeric_limitsIhE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE5radixE */ const int _ZNSt14numeric_limitsIhE5radixE __attribute__((visibility("default")));
# 623 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE12min_exponentE */ const int _ZNSt14numeric_limitsIhE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE14min_exponent10E */ const int _ZNSt14numeric_limitsIhE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE12max_exponentE */ const int _ZNSt14numeric_limitsIhE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE14max_exponent10E */ const int _ZNSt14numeric_limitsIhE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE12has_infinityE */ const char _ZNSt14numeric_limitsIhE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIhE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIhE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIhE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIhE15has_denorm_lossE __attribute__((visibility("default")));
# 651 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE9is_iec559E */ const char _ZNSt14numeric_limitsIhE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE10is_boundedE */ const char _ZNSt14numeric_limitsIhE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE9is_moduloE */ const char _ZNSt14numeric_limitsIhE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE5trapsE */ const char _ZNSt14numeric_limitsIhE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIhE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIhE11round_styleE __attribute__((visibility("default")));
# 665 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE14is_specializedE */ const char _ZNSt14numeric_limitsIwE14is_specializedE __attribute__((visibility("default")));
# 678 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE6digitsE */ const int _ZNSt14numeric_limitsIwE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE8digits10E */ const int _ZNSt14numeric_limitsIwE8digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE12max_digits10E */ const int _ZNSt14numeric_limitsIwE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE9is_signedE */ const char _ZNSt14numeric_limitsIwE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE10is_integerE */ const char _ZNSt14numeric_limitsIwE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE8is_exactE */ const char _ZNSt14numeric_limitsIwE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE5radixE */ const int _ZNSt14numeric_limitsIwE5radixE __attribute__((visibility("default")));
# 695 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE12min_exponentE */ const int _ZNSt14numeric_limitsIwE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE14min_exponent10E */ const int _ZNSt14numeric_limitsIwE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE12max_exponentE */ const int _ZNSt14numeric_limitsIwE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE14max_exponent10E */ const int _ZNSt14numeric_limitsIwE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE12has_infinityE */ const char _ZNSt14numeric_limitsIwE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIwE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIwE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIwE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIwE15has_denorm_lossE __attribute__((visibility("default")));
# 719 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE9is_iec559E */ const char _ZNSt14numeric_limitsIwE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE10is_boundedE */ const char _ZNSt14numeric_limitsIwE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE9is_moduloE */ const char _ZNSt14numeric_limitsIwE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE5trapsE */ const char _ZNSt14numeric_limitsIwE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIwE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIwE11round_styleE __attribute__((visibility("default")));
# 799 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE14is_specializedE */ const char _ZNSt14numeric_limitsIDsE14is_specializedE __attribute__((visibility("default")));
# 810 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE6digitsE */ const int _ZNSt14numeric_limitsIDsE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE8digits10E */ const int _ZNSt14numeric_limitsIDsE8digits10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE12max_digits10E */ const int _ZNSt14numeric_limitsIDsE12max_digits10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE9is_signedE */ const char _ZNSt14numeric_limitsIDsE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE10is_integerE */ const char _ZNSt14numeric_limitsIDsE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE8is_exactE */ const char _ZNSt14numeric_limitsIDsE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE5radixE */ const int _ZNSt14numeric_limitsIDsE5radixE __attribute__((visibility("default")));
# 824 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE12min_exponentE */ const int _ZNSt14numeric_limitsIDsE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE14min_exponent10E */ const int _ZNSt14numeric_limitsIDsE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE12max_exponentE */ const int _ZNSt14numeric_limitsIDsE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE14max_exponent10E */ const int _ZNSt14numeric_limitsIDsE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE12has_infinityE */ const char _ZNSt14numeric_limitsIDsE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIDsE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIDsE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIDsE10has_denormE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIDsE15has_denorm_lossE __attribute__((visibility("default")));
# 847 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE9is_iec559E */ const char _ZNSt14numeric_limitsIDsE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE10is_boundedE */ const char _ZNSt14numeric_limitsIDsE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE9is_moduloE */ const char _ZNSt14numeric_limitsIDsE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE5trapsE */ const char _ZNSt14numeric_limitsIDsE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIDsE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIDsE11round_styleE __attribute__((visibility("default")));
# 860 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE14is_specializedE */ const char _ZNSt14numeric_limitsIDiE14is_specializedE __attribute__((visibility("default")));
# 871 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE6digitsE */ const int _ZNSt14numeric_limitsIDiE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE8digits10E */ const int _ZNSt14numeric_limitsIDiE8digits10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE12max_digits10E */ const int _ZNSt14numeric_limitsIDiE12max_digits10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE9is_signedE */ const char _ZNSt14numeric_limitsIDiE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE10is_integerE */ const char _ZNSt14numeric_limitsIDiE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE8is_exactE */ const char _ZNSt14numeric_limitsIDiE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE5radixE */ const int _ZNSt14numeric_limitsIDiE5radixE __attribute__((visibility("default")));
# 885 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE12min_exponentE */ const int _ZNSt14numeric_limitsIDiE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE14min_exponent10E */ const int _ZNSt14numeric_limitsIDiE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE12max_exponentE */ const int _ZNSt14numeric_limitsIDiE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE14max_exponent10E */ const int _ZNSt14numeric_limitsIDiE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE12has_infinityE */ const char _ZNSt14numeric_limitsIDiE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIDiE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIDiE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIDiE10has_denormE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIDiE15has_denorm_lossE __attribute__((visibility("default")));
# 908 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE9is_iec559E */ const char _ZNSt14numeric_limitsIDiE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE10is_boundedE */ const char _ZNSt14numeric_limitsIDiE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE9is_moduloE */ const char _ZNSt14numeric_limitsIDiE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE5trapsE */ const char _ZNSt14numeric_limitsIDiE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIDiE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIDiE11round_styleE __attribute__((visibility("default")));
# 922 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE14is_specializedE */ const char _ZNSt14numeric_limitsIsE14is_specializedE __attribute__((visibility("default")));
# 935 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE6digitsE */ const int _ZNSt14numeric_limitsIsE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE8digits10E */ const int _ZNSt14numeric_limitsIsE8digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE12max_digits10E */ const int _ZNSt14numeric_limitsIsE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE9is_signedE */ const char _ZNSt14numeric_limitsIsE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE10is_integerE */ const char _ZNSt14numeric_limitsIsE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE8is_exactE */ const char _ZNSt14numeric_limitsIsE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE5radixE */ const int _ZNSt14numeric_limitsIsE5radixE __attribute__((visibility("default")));
# 951 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE12min_exponentE */ const int _ZNSt14numeric_limitsIsE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE14min_exponent10E */ const int _ZNSt14numeric_limitsIsE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE12max_exponentE */ const int _ZNSt14numeric_limitsIsE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE14max_exponent10E */ const int _ZNSt14numeric_limitsIsE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE12has_infinityE */ const char _ZNSt14numeric_limitsIsE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIsE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIsE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIsE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIsE15has_denorm_lossE __attribute__((visibility("default")));
# 975 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE9is_iec559E */ const char _ZNSt14numeric_limitsIsE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE10is_boundedE */ const char _ZNSt14numeric_limitsIsE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE9is_moduloE */ const char _ZNSt14numeric_limitsIsE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE5trapsE */ const char _ZNSt14numeric_limitsIsE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIsE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIsE11round_styleE __attribute__((visibility("default")));
# 989 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE14is_specializedE */ const char _ZNSt14numeric_limitsItE14is_specializedE __attribute__((visibility("default")));
# 1002 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE6digitsE */ const int _ZNSt14numeric_limitsItE6digitsE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE8digits10E */ const int _ZNSt14numeric_limitsItE8digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE12max_digits10E */ const int _ZNSt14numeric_limitsItE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE9is_signedE */ const char _ZNSt14numeric_limitsItE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE10is_integerE */ const char _ZNSt14numeric_limitsItE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE8is_exactE */ const char _ZNSt14numeric_limitsItE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE5radixE */ const int _ZNSt14numeric_limitsItE5radixE __attribute__((visibility("default")));
# 1020 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE12min_exponentE */ const int _ZNSt14numeric_limitsItE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE14min_exponent10E */ const int _ZNSt14numeric_limitsItE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE12max_exponentE */ const int _ZNSt14numeric_limitsItE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE14max_exponent10E */ const int _ZNSt14numeric_limitsItE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE12has_infinityE */ const char _ZNSt14numeric_limitsItE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsItE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsItE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsItE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE15has_denorm_lossE */ const char _ZNSt14numeric_limitsItE15has_denorm_lossE __attribute__((visibility("default")));
# 1048 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE9is_iec559E */ const char _ZNSt14numeric_limitsItE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE10is_boundedE */ const char _ZNSt14numeric_limitsItE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE9is_moduloE */ const char _ZNSt14numeric_limitsItE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE5trapsE */ const char _ZNSt14numeric_limitsItE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE15tinyness_beforeE */ const char _ZNSt14numeric_limitsItE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsItE11round_styleE __attribute__((visibility("default")));
# 1062 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE14is_specializedE */ const char _ZNSt14numeric_limitsIiE14is_specializedE __attribute__((visibility("default")));
# 1075 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE6digitsE */ const int _ZNSt14numeric_limitsIiE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE8digits10E */ const int _ZNSt14numeric_limitsIiE8digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE12max_digits10E */ const int _ZNSt14numeric_limitsIiE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE9is_signedE */ const char _ZNSt14numeric_limitsIiE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE10is_integerE */ const char _ZNSt14numeric_limitsIiE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE8is_exactE */ const char _ZNSt14numeric_limitsIiE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE5radixE */ const int _ZNSt14numeric_limitsIiE5radixE __attribute__((visibility("default")));
# 1091 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE12min_exponentE */ const int _ZNSt14numeric_limitsIiE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE14min_exponent10E */ const int _ZNSt14numeric_limitsIiE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE12max_exponentE */ const int _ZNSt14numeric_limitsIiE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE14max_exponent10E */ const int _ZNSt14numeric_limitsIiE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE12has_infinityE */ const char _ZNSt14numeric_limitsIiE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIiE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIiE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIiE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIiE15has_denorm_lossE __attribute__((visibility("default")));
# 1115 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE9is_iec559E */ const char _ZNSt14numeric_limitsIiE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE10is_boundedE */ const char _ZNSt14numeric_limitsIiE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE9is_moduloE */ const char _ZNSt14numeric_limitsIiE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE5trapsE */ const char _ZNSt14numeric_limitsIiE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIiE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIiE11round_styleE __attribute__((visibility("default")));
# 1129 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE14is_specializedE */ const char _ZNSt14numeric_limitsIjE14is_specializedE __attribute__((visibility("default")));
# 1142 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE6digitsE */ const int _ZNSt14numeric_limitsIjE6digitsE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE8digits10E */ const int _ZNSt14numeric_limitsIjE8digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE12max_digits10E */ const int _ZNSt14numeric_limitsIjE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE9is_signedE */ const char _ZNSt14numeric_limitsIjE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE10is_integerE */ const char _ZNSt14numeric_limitsIjE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE8is_exactE */ const char _ZNSt14numeric_limitsIjE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE5radixE */ const int _ZNSt14numeric_limitsIjE5radixE __attribute__((visibility("default")));
# 1160 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE12min_exponentE */ const int _ZNSt14numeric_limitsIjE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE14min_exponent10E */ const int _ZNSt14numeric_limitsIjE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE12max_exponentE */ const int _ZNSt14numeric_limitsIjE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE14max_exponent10E */ const int _ZNSt14numeric_limitsIjE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE12has_infinityE */ const char _ZNSt14numeric_limitsIjE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIjE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIjE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIjE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIjE15has_denorm_lossE __attribute__((visibility("default")));
# 1187 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE9is_iec559E */ const char _ZNSt14numeric_limitsIjE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE10is_boundedE */ const char _ZNSt14numeric_limitsIjE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE9is_moduloE */ const char _ZNSt14numeric_limitsIjE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE5trapsE */ const char _ZNSt14numeric_limitsIjE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIjE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIjE11round_styleE __attribute__((visibility("default")));
# 1201 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE14is_specializedE */ const char _ZNSt14numeric_limitsIlE14is_specializedE __attribute__((visibility("default")));
# 1214 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE6digitsE */ const int _ZNSt14numeric_limitsIlE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE8digits10E */ const int _ZNSt14numeric_limitsIlE8digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE12max_digits10E */ const int _ZNSt14numeric_limitsIlE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE9is_signedE */ const char _ZNSt14numeric_limitsIlE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE10is_integerE */ const char _ZNSt14numeric_limitsIlE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE8is_exactE */ const char _ZNSt14numeric_limitsIlE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE5radixE */ const int _ZNSt14numeric_limitsIlE5radixE __attribute__((visibility("default")));
# 1230 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE12min_exponentE */ const int _ZNSt14numeric_limitsIlE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE14min_exponent10E */ const int _ZNSt14numeric_limitsIlE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE12max_exponentE */ const int _ZNSt14numeric_limitsIlE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE14max_exponent10E */ const int _ZNSt14numeric_limitsIlE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE12has_infinityE */ const char _ZNSt14numeric_limitsIlE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIlE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIlE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIlE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIlE15has_denorm_lossE __attribute__((visibility("default")));
# 1254 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE9is_iec559E */ const char _ZNSt14numeric_limitsIlE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE10is_boundedE */ const char _ZNSt14numeric_limitsIlE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE9is_moduloE */ const char _ZNSt14numeric_limitsIlE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE5trapsE */ const char _ZNSt14numeric_limitsIlE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIlE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIlE11round_styleE __attribute__((visibility("default")));
# 1268 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE14is_specializedE */ const char _ZNSt14numeric_limitsImE14is_specializedE __attribute__((visibility("default")));
# 1281 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE6digitsE */ const int _ZNSt14numeric_limitsImE6digitsE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE8digits10E */ const int _ZNSt14numeric_limitsImE8digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE12max_digits10E */ const int _ZNSt14numeric_limitsImE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE9is_signedE */ const char _ZNSt14numeric_limitsImE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE10is_integerE */ const char _ZNSt14numeric_limitsImE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE8is_exactE */ const char _ZNSt14numeric_limitsImE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE5radixE */ const int _ZNSt14numeric_limitsImE5radixE __attribute__((visibility("default")));
# 1299 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE12min_exponentE */ const int _ZNSt14numeric_limitsImE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE14min_exponent10E */ const int _ZNSt14numeric_limitsImE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE12max_exponentE */ const int _ZNSt14numeric_limitsImE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE14max_exponent10E */ const int _ZNSt14numeric_limitsImE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE12has_infinityE */ const char _ZNSt14numeric_limitsImE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsImE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsImE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsImE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE15has_denorm_lossE */ const char _ZNSt14numeric_limitsImE15has_denorm_lossE __attribute__((visibility("default")));
# 1327 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE9is_iec559E */ const char _ZNSt14numeric_limitsImE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE10is_boundedE */ const char _ZNSt14numeric_limitsImE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE9is_moduloE */ const char _ZNSt14numeric_limitsImE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE5trapsE */ const char _ZNSt14numeric_limitsImE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE15tinyness_beforeE */ const char _ZNSt14numeric_limitsImE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsImE11round_styleE __attribute__((visibility("default")));
# 1341 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE14is_specializedE */ const char _ZNSt14numeric_limitsIxE14is_specializedE __attribute__((visibility("default")));
# 1354 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE6digitsE */ const int _ZNSt14numeric_limitsIxE6digitsE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE8digits10E */ const int _ZNSt14numeric_limitsIxE8digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE12max_digits10E */ const int _ZNSt14numeric_limitsIxE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE9is_signedE */ const char _ZNSt14numeric_limitsIxE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE10is_integerE */ const char _ZNSt14numeric_limitsIxE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE8is_exactE */ const char _ZNSt14numeric_limitsIxE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE5radixE */ const int _ZNSt14numeric_limitsIxE5radixE __attribute__((visibility("default")));
# 1372 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE12min_exponentE */ const int _ZNSt14numeric_limitsIxE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE14min_exponent10E */ const int _ZNSt14numeric_limitsIxE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE12max_exponentE */ const int _ZNSt14numeric_limitsIxE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE14max_exponent10E */ const int _ZNSt14numeric_limitsIxE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE12has_infinityE */ const char _ZNSt14numeric_limitsIxE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIxE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIxE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIxE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIxE15has_denorm_lossE __attribute__((visibility("default")));
# 1397 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE9is_iec559E */ const char _ZNSt14numeric_limitsIxE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE10is_boundedE */ const char _ZNSt14numeric_limitsIxE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE9is_moduloE */ const char _ZNSt14numeric_limitsIxE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE5trapsE */ const char _ZNSt14numeric_limitsIxE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIxE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIxE11round_styleE __attribute__((visibility("default")));
# 1411 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE14is_specializedE */ const char _ZNSt14numeric_limitsIyE14is_specializedE __attribute__((visibility("default")));
# 1424 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE6digitsE */ const int _ZNSt14numeric_limitsIyE6digitsE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE8digits10E */ const int _ZNSt14numeric_limitsIyE8digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE12max_digits10E */ const int _ZNSt14numeric_limitsIyE12max_digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE9is_signedE */ const char _ZNSt14numeric_limitsIyE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE10is_integerE */ const char _ZNSt14numeric_limitsIyE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE8is_exactE */ const char _ZNSt14numeric_limitsIyE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE5radixE */ const int _ZNSt14numeric_limitsIyE5radixE __attribute__((visibility("default")));
# 1442 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE12min_exponentE */ const int _ZNSt14numeric_limitsIyE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE14min_exponent10E */ const int _ZNSt14numeric_limitsIyE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE12max_exponentE */ const int _ZNSt14numeric_limitsIyE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE14max_exponent10E */ const int _ZNSt14numeric_limitsIyE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE12has_infinityE */ const char _ZNSt14numeric_limitsIyE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIyE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIyE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIyE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIyE15has_denorm_lossE __attribute__((visibility("default")));
# 1470 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE9is_iec559E */ const char _ZNSt14numeric_limitsIyE9is_iec559E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE10is_boundedE */ const char _ZNSt14numeric_limitsIyE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE9is_moduloE */ const char _ZNSt14numeric_limitsIyE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE5trapsE */ const char _ZNSt14numeric_limitsIyE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIyE15tinyness_beforeE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIyE11round_styleE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE14is_specializedE */ const char _ZNSt14numeric_limitsInE14is_specializedE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE6digitsE */ const int _ZNSt14numeric_limitsInE6digitsE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE8digits10E */ const int _ZNSt14numeric_limitsInE8digits10E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE9is_signedE */ const char _ZNSt14numeric_limitsInE9is_signedE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE10is_integerE */ const char _ZNSt14numeric_limitsInE10is_integerE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE8is_exactE */ const char _ZNSt14numeric_limitsInE8is_exactE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE5radixE */ const int _ZNSt14numeric_limitsInE5radixE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE12max_digits10E */ const int _ZNSt14numeric_limitsInE12max_digits10E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE12min_exponentE */ const int _ZNSt14numeric_limitsInE12min_exponentE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE14min_exponent10E */ const int _ZNSt14numeric_limitsInE14min_exponent10E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE12max_exponentE */ const int _ZNSt14numeric_limitsInE12max_exponentE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE14max_exponent10E */ const int _ZNSt14numeric_limitsInE14max_exponent10E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE12has_infinityE */ const char _ZNSt14numeric_limitsInE12has_infinityE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsInE13has_quiet_NaNE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsInE17has_signaling_NaNE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsInE10has_denormE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE15has_denorm_lossE */ const char _ZNSt14numeric_limitsInE15has_denorm_lossE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE9is_iec559E */ const char _ZNSt14numeric_limitsInE9is_iec559E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE10is_boundedE */ const char _ZNSt14numeric_limitsInE10is_boundedE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE9is_moduloE */ const char _ZNSt14numeric_limitsInE9is_moduloE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE5trapsE */ const char _ZNSt14numeric_limitsInE5trapsE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE15tinyness_beforeE */ const char _ZNSt14numeric_limitsInE15tinyness_beforeE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsInE11round_styleE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE14is_specializedE */ const char _ZNSt14numeric_limitsIoE14is_specializedE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE12max_digits10E */ const int _ZNSt14numeric_limitsIoE12max_digits10E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE6digitsE */ const int _ZNSt14numeric_limitsIoE6digitsE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE8digits10E */ const int _ZNSt14numeric_limitsIoE8digits10E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE9is_signedE */ const char _ZNSt14numeric_limitsIoE9is_signedE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE10is_integerE */ const char _ZNSt14numeric_limitsIoE10is_integerE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE8is_exactE */ const char _ZNSt14numeric_limitsIoE8is_exactE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE5radixE */ const int _ZNSt14numeric_limitsIoE5radixE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE12min_exponentE */ const int _ZNSt14numeric_limitsIoE12min_exponentE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE14min_exponent10E */ const int _ZNSt14numeric_limitsIoE14min_exponent10E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE12max_exponentE */ const int _ZNSt14numeric_limitsIoE12max_exponentE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE14max_exponent10E */ const int _ZNSt14numeric_limitsIoE14max_exponent10E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE12has_infinityE */ const char _ZNSt14numeric_limitsIoE12has_infinityE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIoE13has_quiet_NaNE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIoE17has_signaling_NaNE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIoE10has_denormE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIoE15has_denorm_lossE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE9is_iec559E */ const char _ZNSt14numeric_limitsIoE9is_iec559E __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE10is_boundedE */ const char _ZNSt14numeric_limitsIoE10is_boundedE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE9is_moduloE */ const char _ZNSt14numeric_limitsIoE9is_moduloE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE5trapsE */ const char _ZNSt14numeric_limitsIoE5trapsE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIoE15tinyness_beforeE __attribute__((visibility("default")));
# 1635 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIoE11round_styleE __attribute__((visibility("default")));
# 1670 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE14is_specializedE */ const char _ZNSt14numeric_limitsIfE14is_specializedE __attribute__((visibility("default")));
# 1683 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE6digitsE */ const int _ZNSt14numeric_limitsIfE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE8digits10E */ const int _ZNSt14numeric_limitsIfE8digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE12max_digits10E */ const int _ZNSt14numeric_limitsIfE12max_digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE9is_signedE */ const char _ZNSt14numeric_limitsIfE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE10is_integerE */ const char _ZNSt14numeric_limitsIfE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE8is_exactE */ const char _ZNSt14numeric_limitsIfE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE5radixE */ const int _ZNSt14numeric_limitsIfE5radixE __attribute__((visibility("default")));
# 1700 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE12min_exponentE */ const int _ZNSt14numeric_limitsIfE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE14min_exponent10E */ const int _ZNSt14numeric_limitsIfE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE12max_exponentE */ const int _ZNSt14numeric_limitsIfE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE14max_exponent10E */ const int _ZNSt14numeric_limitsIfE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE12has_infinityE */ const char _ZNSt14numeric_limitsIfE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIfE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIfE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIfE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIfE15has_denorm_lossE __attribute__((visibility("default")));
# 1725 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE9is_iec559E */ const char _ZNSt14numeric_limitsIfE9is_iec559E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE10is_boundedE */ const char _ZNSt14numeric_limitsIfE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE9is_moduloE */ const char _ZNSt14numeric_limitsIfE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE5trapsE */ const char _ZNSt14numeric_limitsIfE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIfE15tinyness_beforeE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIfE11round_styleE __attribute__((visibility("default")));
# 1745 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE14is_specializedE */ const char _ZNSt14numeric_limitsIdE14is_specializedE __attribute__((visibility("default")));
# 1758 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE6digitsE */ const int _ZNSt14numeric_limitsIdE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE8digits10E */ const int _ZNSt14numeric_limitsIdE8digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE12max_digits10E */ const int _ZNSt14numeric_limitsIdE12max_digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE9is_signedE */ const char _ZNSt14numeric_limitsIdE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE10is_integerE */ const char _ZNSt14numeric_limitsIdE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE8is_exactE */ const char _ZNSt14numeric_limitsIdE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE5radixE */ const int _ZNSt14numeric_limitsIdE5radixE __attribute__((visibility("default")));
# 1775 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE12min_exponentE */ const int _ZNSt14numeric_limitsIdE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE14min_exponent10E */ const int _ZNSt14numeric_limitsIdE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE12max_exponentE */ const int _ZNSt14numeric_limitsIdE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE14max_exponent10E */ const int _ZNSt14numeric_limitsIdE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE12has_infinityE */ const char _ZNSt14numeric_limitsIdE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIdE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIdE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIdE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIdE15has_denorm_lossE __attribute__((visibility("default")));
# 1800 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE9is_iec559E */ const char _ZNSt14numeric_limitsIdE9is_iec559E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE10is_boundedE */ const char _ZNSt14numeric_limitsIdE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE9is_moduloE */ const char _ZNSt14numeric_limitsIdE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE5trapsE */ const char _ZNSt14numeric_limitsIdE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIdE15tinyness_beforeE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIdE11round_styleE __attribute__((visibility("default")));
# 1820 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE14is_specializedE */ const char _ZNSt14numeric_limitsIeE14is_specializedE __attribute__((visibility("default")));
# 1833 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE6digitsE */ const int _ZNSt14numeric_limitsIeE6digitsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE8digits10E */ const int _ZNSt14numeric_limitsIeE8digits10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE12max_digits10E */ const int _ZNSt14numeric_limitsIeE12max_digits10E __attribute__((visibility("default")));


extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE9is_signedE */ const char _ZNSt14numeric_limitsIeE9is_signedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE10is_integerE */ const char _ZNSt14numeric_limitsIeE10is_integerE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE8is_exactE */ const char _ZNSt14numeric_limitsIeE8is_exactE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE5radixE */ const int _ZNSt14numeric_limitsIeE5radixE __attribute__((visibility("default")));
# 1850 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE12min_exponentE */ const int _ZNSt14numeric_limitsIeE12min_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE14min_exponent10E */ const int _ZNSt14numeric_limitsIeE14min_exponent10E __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE12max_exponentE */ const int _ZNSt14numeric_limitsIeE12max_exponentE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE14max_exponent10E */ const int _ZNSt14numeric_limitsIeE14max_exponent10E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE12has_infinityE */ const char _ZNSt14numeric_limitsIeE12has_infinityE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIeE13has_quiet_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIeE17has_signaling_NaNE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIeE10has_denormE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIeE15has_denorm_lossE __attribute__((visibility("default")));
# 1875 "/usr/include/c++/11/limits" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE9is_iec559E */ const char _ZNSt14numeric_limitsIeE9is_iec559E __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE10is_boundedE */ const char _ZNSt14numeric_limitsIeE10is_boundedE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE9is_moduloE */ const char _ZNSt14numeric_limitsIeE9is_moduloE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE5trapsE */ const char _ZNSt14numeric_limitsIeE5trapsE __attribute__((visibility("default")));
extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIeE15tinyness_beforeE __attribute__((visibility("default")));

extern  __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIeE11round_styleE __attribute__((visibility("default")));
# 83 "/usr/include/c++/11/bits/stl_pair.h" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZSt19piecewise_construct */ const struct _ZSt21piecewise_construct_t _ZSt19piecewise_construct __attribute__((visibility("default")));
# 356 "/usr/include/c++/11/utility" 3
extern  __attribute__((__weak__)) /* COMDAT group: _ZSt8in_place */ const struct _ZSt10in_place_t _ZSt8in_place __attribute__((visibility("default")));
# 64 "CMakeCUDACompilerId.cu"
const char *info_compiler = ((const char *)"INFO:compiler[NVIDIA]");

const char *info_simulate = ((const char *)"INFO:simulate[GNU]");
# 336 "CMakeCUDACompilerId.cu"
static const char info_version[50] = {((char)73),((char)78),((char)70),((char)79),((char)58),((char)99),((char)111),((char)109),((char)112),((char)105),((char)108),((char)101),((char)114),((char)95),((char)118),((char)101),((char)114),((char)115),((char)105),((char)111),((char)110),((char)91),((char)48),((char)48),((char)48),((char)48),((char)48),((char)48),((char)49),((char)49),((char)46),((char)48),((char)48),((char)48),((char)48),((char)48),((char)48),((char)48),((char)56),((char)46),((char)48),((char)48),((char)48),((char)48),((char)48),((char)48),((char)56),((char)57),((char)93),((char)0)};
# 365 "CMakeCUDACompilerId.cu"
static const char info_simulate_version[41] = {((char)73),((char)78),((char)70),((char)79),((char)58),((char)115),((char)105),((char)109),((char)117),((char)108),((char)97),((char)116),((char)101),((char)95),((char)118),((char)101),((char)114),((char)115),((char)105),((char)111),((char)110),((char)91),((char)48),((char)48),((char)48),((char)48),((char)48),((char)48),((char)49),((char)49),((char)46),((char)48),((char)48),((char)48),((char)48),((char)48),((char)48),((char)48),((char)52),((char)93),((char)0)};
# 385 "CMakeCUDACompilerId.cu"
const char *info_platform = ((const char *)"INFO:platform[Linux]");
const char *info_arch = ((const char *)"INFO:arch[]");



const char *info_language_standard_default = ((const char *)"INFO:standard_default[17]");
# 406 "CMakeCUDACompilerId.cu"
const char *info_language_extensions_default = ((const char *)"INFO:extensions_default[ON]");
# 534 "/usr/include/c++/11/bits/cpp_type_traits.h" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt24__is_memcmp_ordered_withISt4byteS0_Lb1EE7__valueE */ const char _ZNSt24__is_memcmp_ordered_withISt4byteS0_Lb1EE7__valueE __attribute__((visibility("default"))) = ((char)1);
# 206 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base14is_specializedE */ const char _ZNSt21__numeric_limits_base14is_specializedE __attribute__((visibility("default"))) = ((char)0);




 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base6digitsE */ const int _ZNSt21__numeric_limits_base6digitsE __attribute__((visibility("default"))) = 0;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base8digits10E */ const int _ZNSt21__numeric_limits_base8digits10E __attribute__((visibility("default"))) = 0;




 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base12max_digits10E */ const int _ZNSt21__numeric_limits_base12max_digits10E __attribute__((visibility("default"))) = 0;



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base9is_signedE */ const char _ZNSt21__numeric_limits_base9is_signedE __attribute__((visibility("default"))) = ((char)0);


 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base10is_integerE */ const char _ZNSt21__numeric_limits_base10is_integerE __attribute__((visibility("default"))) = ((char)0);




 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base8is_exactE */ const char _ZNSt21__numeric_limits_base8is_exactE __attribute__((visibility("default"))) = ((char)0);



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base5radixE */ const int _ZNSt21__numeric_limits_base5radixE __attribute__((visibility("default"))) = 0;



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base12min_exponentE */ const int _ZNSt21__numeric_limits_base12min_exponentE __attribute__((visibility("default"))) = 0;



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base14min_exponent10E */ const int _ZNSt21__numeric_limits_base14min_exponent10E __attribute__((visibility("default"))) = 0;




 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base12max_exponentE */ const int _ZNSt21__numeric_limits_base12max_exponentE __attribute__((visibility("default"))) = 0;



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base14max_exponent10E */ const int _ZNSt21__numeric_limits_base14max_exponent10E __attribute__((visibility("default"))) = 0;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base12has_infinityE */ const char _ZNSt21__numeric_limits_base12has_infinityE __attribute__((visibility("default"))) = ((char)0);



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base13has_quiet_NaNE */ const char _ZNSt21__numeric_limits_base13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base17has_signaling_NaNE */ const char _ZNSt21__numeric_limits_base17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);


 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt21__numeric_limits_base10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base15has_denorm_lossE */ const char _ZNSt21__numeric_limits_base15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);



 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base9is_iec559E */ const char _ZNSt21__numeric_limits_base9is_iec559E __attribute__((visibility("default"))) = ((char)0);




 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base10is_boundedE */ const char _ZNSt21__numeric_limits_base10is_boundedE __attribute__((visibility("default"))) = ((char)0);
# 288 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base9is_moduloE */ const char _ZNSt21__numeric_limits_base9is_moduloE __attribute__((visibility("default"))) = ((char)0);


 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base5trapsE */ const char _ZNSt21__numeric_limits_base5trapsE __attribute__((visibility("default"))) = ((char)0);


 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base15tinyness_beforeE */ const char _ZNSt21__numeric_limits_base15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);




 __attribute__((__weak__)) /* COMDAT group: _ZNSt21__numeric_limits_base11round_styleE */ const enum _ZSt17float_round_style _ZNSt21__numeric_limits_base11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 386 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE14is_specializedE */ const char _ZNSt14numeric_limitsIbE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 398 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE6digitsE */ const int _ZNSt14numeric_limitsIbE6digitsE __attribute__((visibility("default"))) = 1;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE8digits10E */ const int _ZNSt14numeric_limitsIbE8digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE12max_digits10E */ const int _ZNSt14numeric_limitsIbE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE9is_signedE */ const char _ZNSt14numeric_limitsIbE9is_signedE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE10is_integerE */ const char _ZNSt14numeric_limitsIbE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE8is_exactE */ const char _ZNSt14numeric_limitsIbE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE5radixE */ const int _ZNSt14numeric_limitsIbE5radixE __attribute__((visibility("default"))) = 2;
# 414 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE12min_exponentE */ const int _ZNSt14numeric_limitsIbE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE14min_exponent10E */ const int _ZNSt14numeric_limitsIbE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE12max_exponentE */ const int _ZNSt14numeric_limitsIbE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE14max_exponent10E */ const int _ZNSt14numeric_limitsIbE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE12has_infinityE */ const char _ZNSt14numeric_limitsIbE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIbE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIbE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIbE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIbE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 438 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE9is_iec559E */ const char _ZNSt14numeric_limitsIbE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE10is_boundedE */ const char _ZNSt14numeric_limitsIbE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE9is_moduloE */ const char _ZNSt14numeric_limitsIbE9is_moduloE __attribute__((visibility("default"))) = ((char)0);




 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE5trapsE */ const char _ZNSt14numeric_limitsIbE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIbE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIbE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIbE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 455 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE14is_specializedE */ const char _ZNSt14numeric_limitsIcE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 468 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE6digitsE */ const int _ZNSt14numeric_limitsIcE6digitsE __attribute__((visibility("default"))) = 7;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE8digits10E */ const int _ZNSt14numeric_limitsIcE8digits10E __attribute__((visibility("default"))) = 2;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE12max_digits10E */ const int _ZNSt14numeric_limitsIcE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE9is_signedE */ const char _ZNSt14numeric_limitsIcE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE10is_integerE */ const char _ZNSt14numeric_limitsIcE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE8is_exactE */ const char _ZNSt14numeric_limitsIcE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE5radixE */ const int _ZNSt14numeric_limitsIcE5radixE __attribute__((visibility("default"))) = 2;
# 484 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE12min_exponentE */ const int _ZNSt14numeric_limitsIcE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE14min_exponent10E */ const int _ZNSt14numeric_limitsIcE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE12max_exponentE */ const int _ZNSt14numeric_limitsIcE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE14max_exponent10E */ const int _ZNSt14numeric_limitsIcE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE12has_infinityE */ const char _ZNSt14numeric_limitsIcE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIcE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIcE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIcE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIcE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 508 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE9is_iec559E */ const char _ZNSt14numeric_limitsIcE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE10is_boundedE */ const char _ZNSt14numeric_limitsIcE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE9is_moduloE */ const char _ZNSt14numeric_limitsIcE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE5trapsE */ const char _ZNSt14numeric_limitsIcE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIcE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIcE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIcE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 522 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE14is_specializedE */ const char _ZNSt14numeric_limitsIaE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 535 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE6digitsE */ const int _ZNSt14numeric_limitsIaE6digitsE __attribute__((visibility("default"))) = 7;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE8digits10E */ const int _ZNSt14numeric_limitsIaE8digits10E __attribute__((visibility("default"))) = 2;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE12max_digits10E */ const int _ZNSt14numeric_limitsIaE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE9is_signedE */ const char _ZNSt14numeric_limitsIaE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE10is_integerE */ const char _ZNSt14numeric_limitsIaE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE8is_exactE */ const char _ZNSt14numeric_limitsIaE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE5radixE */ const int _ZNSt14numeric_limitsIaE5radixE __attribute__((visibility("default"))) = 2;
# 552 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE12min_exponentE */ const int _ZNSt14numeric_limitsIaE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE14min_exponent10E */ const int _ZNSt14numeric_limitsIaE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE12max_exponentE */ const int _ZNSt14numeric_limitsIaE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE14max_exponent10E */ const int _ZNSt14numeric_limitsIaE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE12has_infinityE */ const char _ZNSt14numeric_limitsIaE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIaE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIaE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIaE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIaE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 578 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE9is_iec559E */ const char _ZNSt14numeric_limitsIaE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE10is_boundedE */ const char _ZNSt14numeric_limitsIaE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE9is_moduloE */ const char _ZNSt14numeric_limitsIaE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE5trapsE */ const char _ZNSt14numeric_limitsIaE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIaE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIaE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIaE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 592 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE14is_specializedE */ const char _ZNSt14numeric_limitsIhE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 605 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE6digitsE */ const int _ZNSt14numeric_limitsIhE6digitsE __attribute__((visibility("default"))) = 8;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE8digits10E */ const int _ZNSt14numeric_limitsIhE8digits10E __attribute__((visibility("default"))) = 2;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE12max_digits10E */ const int _ZNSt14numeric_limitsIhE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE9is_signedE */ const char _ZNSt14numeric_limitsIhE9is_signedE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE10is_integerE */ const char _ZNSt14numeric_limitsIhE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE8is_exactE */ const char _ZNSt14numeric_limitsIhE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE5radixE */ const int _ZNSt14numeric_limitsIhE5radixE __attribute__((visibility("default"))) = 2;
# 623 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE12min_exponentE */ const int _ZNSt14numeric_limitsIhE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE14min_exponent10E */ const int _ZNSt14numeric_limitsIhE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE12max_exponentE */ const int _ZNSt14numeric_limitsIhE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE14max_exponent10E */ const int _ZNSt14numeric_limitsIhE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE12has_infinityE */ const char _ZNSt14numeric_limitsIhE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIhE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIhE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIhE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIhE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 651 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE9is_iec559E */ const char _ZNSt14numeric_limitsIhE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE10is_boundedE */ const char _ZNSt14numeric_limitsIhE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE9is_moduloE */ const char _ZNSt14numeric_limitsIhE9is_moduloE __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE5trapsE */ const char _ZNSt14numeric_limitsIhE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIhE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIhE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIhE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 665 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE14is_specializedE */ const char _ZNSt14numeric_limitsIwE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 678 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE6digitsE */ const int _ZNSt14numeric_limitsIwE6digitsE __attribute__((visibility("default"))) = 31;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE8digits10E */ const int _ZNSt14numeric_limitsIwE8digits10E __attribute__((visibility("default"))) = 9;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE12max_digits10E */ const int _ZNSt14numeric_limitsIwE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE9is_signedE */ const char _ZNSt14numeric_limitsIwE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE10is_integerE */ const char _ZNSt14numeric_limitsIwE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE8is_exactE */ const char _ZNSt14numeric_limitsIwE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE5radixE */ const int _ZNSt14numeric_limitsIwE5radixE __attribute__((visibility("default"))) = 2;
# 695 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE12min_exponentE */ const int _ZNSt14numeric_limitsIwE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE14min_exponent10E */ const int _ZNSt14numeric_limitsIwE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE12max_exponentE */ const int _ZNSt14numeric_limitsIwE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE14max_exponent10E */ const int _ZNSt14numeric_limitsIwE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE12has_infinityE */ const char _ZNSt14numeric_limitsIwE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIwE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIwE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIwE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIwE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 719 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE9is_iec559E */ const char _ZNSt14numeric_limitsIwE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE10is_boundedE */ const char _ZNSt14numeric_limitsIwE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE9is_moduloE */ const char _ZNSt14numeric_limitsIwE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE5trapsE */ const char _ZNSt14numeric_limitsIwE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIwE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIwE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIwE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 799 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE14is_specializedE */ const char _ZNSt14numeric_limitsIDsE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 810 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE6digitsE */ const int _ZNSt14numeric_limitsIDsE6digitsE __attribute__((visibility("default"))) = 16;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE8digits10E */ const int _ZNSt14numeric_limitsIDsE8digits10E __attribute__((visibility("default"))) = 4;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE12max_digits10E */ const int _ZNSt14numeric_limitsIDsE12max_digits10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE9is_signedE */ const char _ZNSt14numeric_limitsIDsE9is_signedE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE10is_integerE */ const char _ZNSt14numeric_limitsIDsE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE8is_exactE */ const char _ZNSt14numeric_limitsIDsE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE5radixE */ const int _ZNSt14numeric_limitsIDsE5radixE __attribute__((visibility("default"))) = 2;
# 824 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE12min_exponentE */ const int _ZNSt14numeric_limitsIDsE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE14min_exponent10E */ const int _ZNSt14numeric_limitsIDsE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE12max_exponentE */ const int _ZNSt14numeric_limitsIDsE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE14max_exponent10E */ const int _ZNSt14numeric_limitsIDsE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE12has_infinityE */ const char _ZNSt14numeric_limitsIDsE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIDsE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIDsE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIDsE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIDsE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 847 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE9is_iec559E */ const char _ZNSt14numeric_limitsIDsE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE10is_boundedE */ const char _ZNSt14numeric_limitsIDsE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE9is_moduloE */ const char _ZNSt14numeric_limitsIDsE9is_moduloE __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE5trapsE */ const char _ZNSt14numeric_limitsIDsE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIDsE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDsE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIDsE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 860 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE14is_specializedE */ const char _ZNSt14numeric_limitsIDiE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 871 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE6digitsE */ const int _ZNSt14numeric_limitsIDiE6digitsE __attribute__((visibility("default"))) = 32;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE8digits10E */ const int _ZNSt14numeric_limitsIDiE8digits10E __attribute__((visibility("default"))) = 9;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE12max_digits10E */ const int _ZNSt14numeric_limitsIDiE12max_digits10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE9is_signedE */ const char _ZNSt14numeric_limitsIDiE9is_signedE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE10is_integerE */ const char _ZNSt14numeric_limitsIDiE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE8is_exactE */ const char _ZNSt14numeric_limitsIDiE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE5radixE */ const int _ZNSt14numeric_limitsIDiE5radixE __attribute__((visibility("default"))) = 2;
# 885 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE12min_exponentE */ const int _ZNSt14numeric_limitsIDiE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE14min_exponent10E */ const int _ZNSt14numeric_limitsIDiE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE12max_exponentE */ const int _ZNSt14numeric_limitsIDiE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE14max_exponent10E */ const int _ZNSt14numeric_limitsIDiE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE12has_infinityE */ const char _ZNSt14numeric_limitsIDiE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIDiE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIDiE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIDiE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIDiE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 908 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE9is_iec559E */ const char _ZNSt14numeric_limitsIDiE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE10is_boundedE */ const char _ZNSt14numeric_limitsIDiE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE9is_moduloE */ const char _ZNSt14numeric_limitsIDiE9is_moduloE __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE5trapsE */ const char _ZNSt14numeric_limitsIDiE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIDiE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIDiE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIDiE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 922 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE14is_specializedE */ const char _ZNSt14numeric_limitsIsE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 935 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE6digitsE */ const int _ZNSt14numeric_limitsIsE6digitsE __attribute__((visibility("default"))) = 15;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE8digits10E */ const int _ZNSt14numeric_limitsIsE8digits10E __attribute__((visibility("default"))) = 4;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE12max_digits10E */ const int _ZNSt14numeric_limitsIsE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE9is_signedE */ const char _ZNSt14numeric_limitsIsE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE10is_integerE */ const char _ZNSt14numeric_limitsIsE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE8is_exactE */ const char _ZNSt14numeric_limitsIsE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE5radixE */ const int _ZNSt14numeric_limitsIsE5radixE __attribute__((visibility("default"))) = 2;
# 951 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE12min_exponentE */ const int _ZNSt14numeric_limitsIsE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE14min_exponent10E */ const int _ZNSt14numeric_limitsIsE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE12max_exponentE */ const int _ZNSt14numeric_limitsIsE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE14max_exponent10E */ const int _ZNSt14numeric_limitsIsE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE12has_infinityE */ const char _ZNSt14numeric_limitsIsE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIsE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIsE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIsE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIsE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 975 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE9is_iec559E */ const char _ZNSt14numeric_limitsIsE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE10is_boundedE */ const char _ZNSt14numeric_limitsIsE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE9is_moduloE */ const char _ZNSt14numeric_limitsIsE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE5trapsE */ const char _ZNSt14numeric_limitsIsE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIsE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIsE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIsE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 989 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE14is_specializedE */ const char _ZNSt14numeric_limitsItE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1002 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE6digitsE */ const int _ZNSt14numeric_limitsItE6digitsE __attribute__((visibility("default"))) = 16;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE8digits10E */ const int _ZNSt14numeric_limitsItE8digits10E __attribute__((visibility("default"))) = 4;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE12max_digits10E */ const int _ZNSt14numeric_limitsItE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE9is_signedE */ const char _ZNSt14numeric_limitsItE9is_signedE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE10is_integerE */ const char _ZNSt14numeric_limitsItE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE8is_exactE */ const char _ZNSt14numeric_limitsItE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE5radixE */ const int _ZNSt14numeric_limitsItE5radixE __attribute__((visibility("default"))) = 2;
# 1020 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE12min_exponentE */ const int _ZNSt14numeric_limitsItE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE14min_exponent10E */ const int _ZNSt14numeric_limitsItE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE12max_exponentE */ const int _ZNSt14numeric_limitsItE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE14max_exponent10E */ const int _ZNSt14numeric_limitsItE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE12has_infinityE */ const char _ZNSt14numeric_limitsItE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsItE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsItE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsItE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE15has_denorm_lossE */ const char _ZNSt14numeric_limitsItE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1048 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE9is_iec559E */ const char _ZNSt14numeric_limitsItE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE10is_boundedE */ const char _ZNSt14numeric_limitsItE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE9is_moduloE */ const char _ZNSt14numeric_limitsItE9is_moduloE __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE5trapsE */ const char _ZNSt14numeric_limitsItE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE15tinyness_beforeE */ const char _ZNSt14numeric_limitsItE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsItE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsItE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1062 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE14is_specializedE */ const char _ZNSt14numeric_limitsIiE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1075 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE6digitsE */ const int _ZNSt14numeric_limitsIiE6digitsE __attribute__((visibility("default"))) = 31;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE8digits10E */ const int _ZNSt14numeric_limitsIiE8digits10E __attribute__((visibility("default"))) = 9;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE12max_digits10E */ const int _ZNSt14numeric_limitsIiE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE9is_signedE */ const char _ZNSt14numeric_limitsIiE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE10is_integerE */ const char _ZNSt14numeric_limitsIiE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE8is_exactE */ const char _ZNSt14numeric_limitsIiE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE5radixE */ const int _ZNSt14numeric_limitsIiE5radixE __attribute__((visibility("default"))) = 2;
# 1091 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE12min_exponentE */ const int _ZNSt14numeric_limitsIiE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE14min_exponent10E */ const int _ZNSt14numeric_limitsIiE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE12max_exponentE */ const int _ZNSt14numeric_limitsIiE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE14max_exponent10E */ const int _ZNSt14numeric_limitsIiE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE12has_infinityE */ const char _ZNSt14numeric_limitsIiE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIiE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIiE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIiE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIiE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1115 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE9is_iec559E */ const char _ZNSt14numeric_limitsIiE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE10is_boundedE */ const char _ZNSt14numeric_limitsIiE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE9is_moduloE */ const char _ZNSt14numeric_limitsIiE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE5trapsE */ const char _ZNSt14numeric_limitsIiE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIiE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIiE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIiE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1129 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE14is_specializedE */ const char _ZNSt14numeric_limitsIjE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1142 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE6digitsE */ const int _ZNSt14numeric_limitsIjE6digitsE __attribute__((visibility("default"))) = 32;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE8digits10E */ const int _ZNSt14numeric_limitsIjE8digits10E __attribute__((visibility("default"))) = 9;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE12max_digits10E */ const int _ZNSt14numeric_limitsIjE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE9is_signedE */ const char _ZNSt14numeric_limitsIjE9is_signedE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE10is_integerE */ const char _ZNSt14numeric_limitsIjE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE8is_exactE */ const char _ZNSt14numeric_limitsIjE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE5radixE */ const int _ZNSt14numeric_limitsIjE5radixE __attribute__((visibility("default"))) = 2;
# 1160 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE12min_exponentE */ const int _ZNSt14numeric_limitsIjE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE14min_exponent10E */ const int _ZNSt14numeric_limitsIjE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE12max_exponentE */ const int _ZNSt14numeric_limitsIjE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE14max_exponent10E */ const int _ZNSt14numeric_limitsIjE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE12has_infinityE */ const char _ZNSt14numeric_limitsIjE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIjE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIjE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIjE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIjE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1187 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE9is_iec559E */ const char _ZNSt14numeric_limitsIjE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE10is_boundedE */ const char _ZNSt14numeric_limitsIjE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE9is_moduloE */ const char _ZNSt14numeric_limitsIjE9is_moduloE __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE5trapsE */ const char _ZNSt14numeric_limitsIjE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIjE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIjE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIjE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1201 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE14is_specializedE */ const char _ZNSt14numeric_limitsIlE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1214 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE6digitsE */ const int _ZNSt14numeric_limitsIlE6digitsE __attribute__((visibility("default"))) = 63;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE8digits10E */ const int _ZNSt14numeric_limitsIlE8digits10E __attribute__((visibility("default"))) = 18;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE12max_digits10E */ const int _ZNSt14numeric_limitsIlE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE9is_signedE */ const char _ZNSt14numeric_limitsIlE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE10is_integerE */ const char _ZNSt14numeric_limitsIlE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE8is_exactE */ const char _ZNSt14numeric_limitsIlE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE5radixE */ const int _ZNSt14numeric_limitsIlE5radixE __attribute__((visibility("default"))) = 2;
# 1230 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE12min_exponentE */ const int _ZNSt14numeric_limitsIlE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE14min_exponent10E */ const int _ZNSt14numeric_limitsIlE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE12max_exponentE */ const int _ZNSt14numeric_limitsIlE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE14max_exponent10E */ const int _ZNSt14numeric_limitsIlE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE12has_infinityE */ const char _ZNSt14numeric_limitsIlE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIlE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIlE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIlE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIlE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1254 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE9is_iec559E */ const char _ZNSt14numeric_limitsIlE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE10is_boundedE */ const char _ZNSt14numeric_limitsIlE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE9is_moduloE */ const char _ZNSt14numeric_limitsIlE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE5trapsE */ const char _ZNSt14numeric_limitsIlE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIlE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIlE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIlE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1268 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE14is_specializedE */ const char _ZNSt14numeric_limitsImE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1281 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE6digitsE */ const int _ZNSt14numeric_limitsImE6digitsE __attribute__((visibility("default"))) = 64;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE8digits10E */ const int _ZNSt14numeric_limitsImE8digits10E __attribute__((visibility("default"))) = 19;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE12max_digits10E */ const int _ZNSt14numeric_limitsImE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE9is_signedE */ const char _ZNSt14numeric_limitsImE9is_signedE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE10is_integerE */ const char _ZNSt14numeric_limitsImE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE8is_exactE */ const char _ZNSt14numeric_limitsImE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE5radixE */ const int _ZNSt14numeric_limitsImE5radixE __attribute__((visibility("default"))) = 2;
# 1299 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE12min_exponentE */ const int _ZNSt14numeric_limitsImE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE14min_exponent10E */ const int _ZNSt14numeric_limitsImE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE12max_exponentE */ const int _ZNSt14numeric_limitsImE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE14max_exponent10E */ const int _ZNSt14numeric_limitsImE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE12has_infinityE */ const char _ZNSt14numeric_limitsImE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsImE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsImE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsImE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE15has_denorm_lossE */ const char _ZNSt14numeric_limitsImE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1327 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE9is_iec559E */ const char _ZNSt14numeric_limitsImE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE10is_boundedE */ const char _ZNSt14numeric_limitsImE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE9is_moduloE */ const char _ZNSt14numeric_limitsImE9is_moduloE __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE5trapsE */ const char _ZNSt14numeric_limitsImE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE15tinyness_beforeE */ const char _ZNSt14numeric_limitsImE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsImE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsImE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1341 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE14is_specializedE */ const char _ZNSt14numeric_limitsIxE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1354 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE6digitsE */ const int _ZNSt14numeric_limitsIxE6digitsE __attribute__((visibility("default"))) = 63;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE8digits10E */ const int _ZNSt14numeric_limitsIxE8digits10E __attribute__((visibility("default"))) = 18;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE12max_digits10E */ const int _ZNSt14numeric_limitsIxE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE9is_signedE */ const char _ZNSt14numeric_limitsIxE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE10is_integerE */ const char _ZNSt14numeric_limitsIxE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE8is_exactE */ const char _ZNSt14numeric_limitsIxE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE5radixE */ const int _ZNSt14numeric_limitsIxE5radixE __attribute__((visibility("default"))) = 2;
# 1372 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE12min_exponentE */ const int _ZNSt14numeric_limitsIxE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE14min_exponent10E */ const int _ZNSt14numeric_limitsIxE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE12max_exponentE */ const int _ZNSt14numeric_limitsIxE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE14max_exponent10E */ const int _ZNSt14numeric_limitsIxE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE12has_infinityE */ const char _ZNSt14numeric_limitsIxE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIxE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIxE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIxE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIxE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1397 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE9is_iec559E */ const char _ZNSt14numeric_limitsIxE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE10is_boundedE */ const char _ZNSt14numeric_limitsIxE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE9is_moduloE */ const char _ZNSt14numeric_limitsIxE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE5trapsE */ const char _ZNSt14numeric_limitsIxE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIxE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIxE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIxE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1411 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE14is_specializedE */ const char _ZNSt14numeric_limitsIyE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1424 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE6digitsE */ const int _ZNSt14numeric_limitsIyE6digitsE __attribute__((visibility("default"))) = 64;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE8digits10E */ const int _ZNSt14numeric_limitsIyE8digits10E __attribute__((visibility("default"))) = 19;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE12max_digits10E */ const int _ZNSt14numeric_limitsIyE12max_digits10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE9is_signedE */ const char _ZNSt14numeric_limitsIyE9is_signedE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE10is_integerE */ const char _ZNSt14numeric_limitsIyE10is_integerE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE8is_exactE */ const char _ZNSt14numeric_limitsIyE8is_exactE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE5radixE */ const int _ZNSt14numeric_limitsIyE5radixE __attribute__((visibility("default"))) = 2;
# 1442 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE12min_exponentE */ const int _ZNSt14numeric_limitsIyE12min_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE14min_exponent10E */ const int _ZNSt14numeric_limitsIyE14min_exponent10E __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE12max_exponentE */ const int _ZNSt14numeric_limitsIyE12max_exponentE __attribute__((visibility("default"))) = 0;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE14max_exponent10E */ const int _ZNSt14numeric_limitsIyE14max_exponent10E __attribute__((visibility("default"))) = 0;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE12has_infinityE */ const char _ZNSt14numeric_limitsIyE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIyE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIyE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIyE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIyE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1470 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE9is_iec559E */ const char _ZNSt14numeric_limitsIyE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE10is_boundedE */ const char _ZNSt14numeric_limitsIyE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE9is_moduloE */ const char _ZNSt14numeric_limitsIyE9is_moduloE __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE5trapsE */ const char _ZNSt14numeric_limitsIyE5trapsE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIyE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIyE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIyE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE14is_specializedE */ const char _ZNSt14numeric_limitsInE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE6digitsE */ const int _ZNSt14numeric_limitsInE6digitsE __attribute__((visibility("default"))) = 127;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE8digits10E */ const int _ZNSt14numeric_limitsInE8digits10E __attribute__((visibility("default"))) = 38;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE9is_signedE */ const char _ZNSt14numeric_limitsInE9is_signedE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE10is_integerE */ const char _ZNSt14numeric_limitsInE10is_integerE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE8is_exactE */ const char _ZNSt14numeric_limitsInE8is_exactE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE5radixE */ const int _ZNSt14numeric_limitsInE5radixE __attribute__((visibility("default"))) = 2;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE12max_digits10E */ const int _ZNSt14numeric_limitsInE12max_digits10E __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE12min_exponentE */ const int _ZNSt14numeric_limitsInE12min_exponentE __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE14min_exponent10E */ const int _ZNSt14numeric_limitsInE14min_exponent10E __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE12max_exponentE */ const int _ZNSt14numeric_limitsInE12max_exponentE __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE14max_exponent10E */ const int _ZNSt14numeric_limitsInE14max_exponent10E __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE12has_infinityE */ const char _ZNSt14numeric_limitsInE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsInE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsInE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsInE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE15has_denorm_lossE */ const char _ZNSt14numeric_limitsInE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE9is_iec559E */ const char _ZNSt14numeric_limitsInE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE10is_boundedE */ const char _ZNSt14numeric_limitsInE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE9is_moduloE */ const char _ZNSt14numeric_limitsInE9is_moduloE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE5trapsE */ const char _ZNSt14numeric_limitsInE5trapsE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE15tinyness_beforeE */ const char _ZNSt14numeric_limitsInE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsInE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsInE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE14is_specializedE */ const char _ZNSt14numeric_limitsIoE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE12max_digits10E */ const int _ZNSt14numeric_limitsIoE12max_digits10E __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE6digitsE */ const int _ZNSt14numeric_limitsIoE6digitsE __attribute__((visibility("default"))) = 128;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE8digits10E */ const int _ZNSt14numeric_limitsIoE8digits10E __attribute__((visibility("default"))) = 38;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE9is_signedE */ const char _ZNSt14numeric_limitsIoE9is_signedE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE10is_integerE */ const char _ZNSt14numeric_limitsIoE10is_integerE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE8is_exactE */ const char _ZNSt14numeric_limitsIoE8is_exactE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE5radixE */ const int _ZNSt14numeric_limitsIoE5radixE __attribute__((visibility("default"))) = 2;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE12min_exponentE */ const int _ZNSt14numeric_limitsIoE12min_exponentE __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE14min_exponent10E */ const int _ZNSt14numeric_limitsIoE14min_exponent10E __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE12max_exponentE */ const int _ZNSt14numeric_limitsIoE12max_exponentE __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE14max_exponent10E */ const int _ZNSt14numeric_limitsIoE14max_exponent10E __attribute__((visibility("default"))) = 0;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE12has_infinityE */ const char _ZNSt14numeric_limitsIoE12has_infinityE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIoE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIoE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIoE10has_denormE __attribute__((visibility("default"))) = _ZSt13denorm_absent;
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIoE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE9is_iec559E */ const char _ZNSt14numeric_limitsIoE9is_iec559E __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE10is_boundedE */ const char _ZNSt14numeric_limitsIoE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE9is_moduloE */ const char _ZNSt14numeric_limitsIoE9is_moduloE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE5trapsE */ const char _ZNSt14numeric_limitsIoE5trapsE __attribute__((visibility("default"))) = ((char)1);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIoE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);
# 1635 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIoE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIoE11round_styleE __attribute__((visibility("default"))) = _ZSt17round_toward_zero;
# 1670 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE14is_specializedE */ const char _ZNSt14numeric_limitsIfE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1683 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE6digitsE */ const int _ZNSt14numeric_limitsIfE6digitsE __attribute__((visibility("default"))) = 24;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE8digits10E */ const int _ZNSt14numeric_limitsIfE8digits10E __attribute__((visibility("default"))) = 6;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE12max_digits10E */ const int _ZNSt14numeric_limitsIfE12max_digits10E __attribute__((visibility("default"))) = 9;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE9is_signedE */ const char _ZNSt14numeric_limitsIfE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE10is_integerE */ const char _ZNSt14numeric_limitsIfE10is_integerE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE8is_exactE */ const char _ZNSt14numeric_limitsIfE8is_exactE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE5radixE */ const int _ZNSt14numeric_limitsIfE5radixE __attribute__((visibility("default"))) = 2;
# 1700 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE12min_exponentE */ const int _ZNSt14numeric_limitsIfE12min_exponentE __attribute__((visibility("default"))) = (-125);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE14min_exponent10E */ const int _ZNSt14numeric_limitsIfE14min_exponent10E __attribute__((visibility("default"))) = (-37);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE12max_exponentE */ const int _ZNSt14numeric_limitsIfE12max_exponentE __attribute__((visibility("default"))) = 128;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE14max_exponent10E */ const int _ZNSt14numeric_limitsIfE14max_exponent10E __attribute__((visibility("default"))) = 38;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE12has_infinityE */ const char _ZNSt14numeric_limitsIfE12has_infinityE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIfE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIfE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIfE10has_denormE __attribute__((visibility("default"))) = _ZSt14denorm_present;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIfE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1725 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE9is_iec559E */ const char _ZNSt14numeric_limitsIfE9is_iec559E __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE10is_boundedE */ const char _ZNSt14numeric_limitsIfE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE9is_moduloE */ const char _ZNSt14numeric_limitsIfE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE5trapsE */ const char _ZNSt14numeric_limitsIfE5trapsE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIfE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIfE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIfE11round_styleE __attribute__((visibility("default"))) = _ZSt16round_to_nearest;
# 1745 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE14is_specializedE */ const char _ZNSt14numeric_limitsIdE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1758 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE6digitsE */ const int _ZNSt14numeric_limitsIdE6digitsE __attribute__((visibility("default"))) = 53;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE8digits10E */ const int _ZNSt14numeric_limitsIdE8digits10E __attribute__((visibility("default"))) = 15;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE12max_digits10E */ const int _ZNSt14numeric_limitsIdE12max_digits10E __attribute__((visibility("default"))) = 17;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE9is_signedE */ const char _ZNSt14numeric_limitsIdE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE10is_integerE */ const char _ZNSt14numeric_limitsIdE10is_integerE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE8is_exactE */ const char _ZNSt14numeric_limitsIdE8is_exactE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE5radixE */ const int _ZNSt14numeric_limitsIdE5radixE __attribute__((visibility("default"))) = 2;
# 1775 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE12min_exponentE */ const int _ZNSt14numeric_limitsIdE12min_exponentE __attribute__((visibility("default"))) = (-1021);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE14min_exponent10E */ const int _ZNSt14numeric_limitsIdE14min_exponent10E __attribute__((visibility("default"))) = (-307);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE12max_exponentE */ const int _ZNSt14numeric_limitsIdE12max_exponentE __attribute__((visibility("default"))) = 1024;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE14max_exponent10E */ const int _ZNSt14numeric_limitsIdE14max_exponent10E __attribute__((visibility("default"))) = 308;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE12has_infinityE */ const char _ZNSt14numeric_limitsIdE12has_infinityE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIdE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIdE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIdE10has_denormE __attribute__((visibility("default"))) = _ZSt14denorm_present;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIdE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1800 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE9is_iec559E */ const char _ZNSt14numeric_limitsIdE9is_iec559E __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE10is_boundedE */ const char _ZNSt14numeric_limitsIdE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE9is_moduloE */ const char _ZNSt14numeric_limitsIdE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE5trapsE */ const char _ZNSt14numeric_limitsIdE5trapsE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIdE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIdE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIdE11round_styleE __attribute__((visibility("default"))) = _ZSt16round_to_nearest;
# 1820 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE14is_specializedE */ const char _ZNSt14numeric_limitsIeE14is_specializedE __attribute__((visibility("default"))) = ((char)1);
# 1833 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE6digitsE */ const int _ZNSt14numeric_limitsIeE6digitsE __attribute__((visibility("default"))) = 64;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE8digits10E */ const int _ZNSt14numeric_limitsIeE8digits10E __attribute__((visibility("default"))) = 18;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE12max_digits10E */ const int _ZNSt14numeric_limitsIeE12max_digits10E __attribute__((visibility("default"))) = 21;


 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE9is_signedE */ const char _ZNSt14numeric_limitsIeE9is_signedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE10is_integerE */ const char _ZNSt14numeric_limitsIeE10is_integerE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE8is_exactE */ const char _ZNSt14numeric_limitsIeE8is_exactE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE5radixE */ const int _ZNSt14numeric_limitsIeE5radixE __attribute__((visibility("default"))) = 2;
# 1850 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE12min_exponentE */ const int _ZNSt14numeric_limitsIeE12min_exponentE __attribute__((visibility("default"))) = (-16381);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE14min_exponent10E */ const int _ZNSt14numeric_limitsIeE14min_exponent10E __attribute__((visibility("default"))) = (-4931);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE12max_exponentE */ const int _ZNSt14numeric_limitsIeE12max_exponentE __attribute__((visibility("default"))) = 16384;
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE14max_exponent10E */ const int _ZNSt14numeric_limitsIeE14max_exponent10E __attribute__((visibility("default"))) = 4932;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE12has_infinityE */ const char _ZNSt14numeric_limitsIeE12has_infinityE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE13has_quiet_NaNE */ const char _ZNSt14numeric_limitsIeE13has_quiet_NaNE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE17has_signaling_NaNE */ const char _ZNSt14numeric_limitsIeE17has_signaling_NaNE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE10has_denormE */ const enum _ZSt18float_denorm_style _ZNSt14numeric_limitsIeE10has_denormE __attribute__((visibility("default"))) = _ZSt14denorm_present;

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE15has_denorm_lossE */ const char _ZNSt14numeric_limitsIeE15has_denorm_lossE __attribute__((visibility("default"))) = ((char)0);
# 1875 "/usr/include/c++/11/limits" 3
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE9is_iec559E */ const char _ZNSt14numeric_limitsIeE9is_iec559E __attribute__((visibility("default"))) = ((char)1);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE10is_boundedE */ const char _ZNSt14numeric_limitsIeE10is_boundedE __attribute__((visibility("default"))) = ((char)1);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE9is_moduloE */ const char _ZNSt14numeric_limitsIeE9is_moduloE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE5trapsE */ const char _ZNSt14numeric_limitsIeE5trapsE __attribute__((visibility("default"))) = ((char)0);
 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE15tinyness_beforeE */ const char _ZNSt14numeric_limitsIeE15tinyness_beforeE __attribute__((visibility("default"))) = ((char)0);

 __attribute__((__weak__)) /* COMDAT group: _ZNSt14numeric_limitsIeE11round_styleE */ const enum _ZSt17float_round_style _ZNSt14numeric_limitsIeE11round_styleE __attribute__((visibility("default"))) = _ZSt16round_to_nearest;
# 83 "/usr/include/c++/11/bits/stl_pair.h" 3
 __attribute__((__weak__)) /* COMDAT group: _ZSt19piecewise_construct */ const struct _ZSt21piecewise_construct_t _ZSt19piecewise_construct __attribute__((visibility("default"))) = {};
# 356 "/usr/include/c++/11/utility" 3
 __attribute__((__weak__)) /* COMDAT group: _ZSt8in_place */ const struct _ZSt10in_place_t _ZSt8in_place __attribute__((visibility("default"))) = {};
